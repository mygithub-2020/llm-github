from flask import Flask, render_template, request, jsonify
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import numpy as np

app = Flask(__name__)

# documents database ( in simple list format)
documents = [
    "This is a new AI analytics tool that helps analyze data efficiently.",
    "The latest finance report shows growth in investment portfolios.",
    "Cloud infrastructure services include AWS and Azure platforms.",
    "Our marketing campaign focuses on SEO strategies to boost traffic.",
    "The AI tool leverages machine learning to enhance performance."
]

# Initialize embedding model and pre-compute document embeddings (global)
embedder = SentenceTransformer('all-MiniLM-L6-v2')
doc_embeddings = embedder.encode(documents)

# In-memory database
query_db = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process_query', methods=['POST'])
def process_query():
    data = request.get_json()
    query = data.get('query', '')
    
    if not query:
        return jsonify({'response': 'Please enter a query.'})
    
    # RAG logic
    query_embedding = embedder.encode([query])
    cosine_similarities = cosine_similarity(query_embedding, doc_embeddings)
    
    # Most relevant document
    most_relevant_doc_index = np.argmax(cosine_similarities)
    most_relevant_doc = documents[most_relevant_doc_index]
    top_score = cosine_similarities[0][most_relevant_doc_index]
    
    # Top k documents
    k = 5
    k = min(k, len(documents))
    top_k_indices = np.argpartition(cosine_similarities[0], -k)[-k:]
    top_k_sorted_indices = top_k_indices[np.argsort(cosine_similarities[0][top_k_indices])[::-1]]
    
    # Build response
    top_k_results = []
    for idx in top_k_sorted_indices:
        top_k_results.append(f"Score: {cosine_similarities[0][idx]:.4f} - {documents[idx]}")
    
    response = (
        f"Most relevant: {most_relevant_doc} (Score: {top_score:.4f})\n\n"
        f"Top {k} matches:\n" + "\n".join(top_k_results)
    )
    
    # Store in database
    entry = {'query': query, 'response': response}
    query_db.append(entry)
    
    return jsonify({'response': response})

@app.route('/history', methods=['GET'])
def history():
    return jsonify({'queries': query_db})

if __name__ == '__main__':
    app.run(debug=True)


