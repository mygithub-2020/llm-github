document.getElementById('queryForm').addEventListener('submit', async (e) => {
    e.preventDefault();  // Prevent page reload
    const queryInput = document.getElementById('queryInput');
    const responseArea = document.getElementById('responseArea');
    
    const query = queryInput.value.trim();
    if (!query) return;  // Skip empty queries
    
    // Show loading state
    responseArea.innerHTML = '<p>Processing your query...</p>';
    queryInput.value = '';  // Clear input
    
    try {
        const res = await fetch('/process_query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: query })
        });
        
        if (!res.ok) throw new Error('Server error');
        
        const data = await res.json();
        // Update display area with response
        responseArea.innerHTML = `
            <div class="query-result">
                <h3>Query: "${query}"</h3>
                <p><strong>Response:</strong> ${data.response}</p>
                <button onclick="loadHistory()">View History</button>
            </div>
        `;
    } catch (error) {
        responseArea.innerHTML = `<p style="color: red;">Error: ${error.message}</p>`;
    }
});

// Load query history from backend
async function loadHistory() {
    try {
        const res = await fetch('/history');
        const data = await res.json();
        const responseArea = document.getElementById('responseArea');
        
        let historyHtml = '<h3>Query History</h3><ul>';
        data.queries.slice(-5).forEach(entry => {  // Show last 5
            historyHtml += `<li><strong>${entry.query}</strong>: ${entry.response}</li>`;
        });
        historyHtml += '</ul>';
        responseArea.innerHTML = historyHtml;
    } catch (error) {
        console.error('History load failed:', error);
    }
}