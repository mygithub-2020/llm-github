from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
from transformers import pipeline
import numpy as np

# Define documents (your database chunks)
documents = [
    "This is a new AI analytics tool that helps analyze data efficiently.",
    "The latest finance report shows growth in investment portfolios.",
    "Cloud infrastructure services include AWS and Azure platforms.",
    "Our marketing campaign focuses on SEO strategies to boost traffic.",
    "The AI tool leverages machine learning to enhance performance."
]
query = "AI and machine learning"
# initialize embedding and embedding documents and query and indexing
embedder = SentenceTransformer('all-MiniLM-L6-v2')
doc_embeddings = embedder.encode(documents)
query_embedding = embedder.encode([query])


# Compute cosine similarity between query and all document embeddings
cosine_similarities = cosine_similarity(query_embedding, doc_embeddings)

# Find the index of the document with highest similarity score
most_relevant_doc_index = np.argmax(cosine_similarities)

print(f"Most relevant document:\n{documents[most_relevant_doc_index]}")
print(f"Similarity score: {cosine_similarities[0][most_relevant_doc_index]:.4f}")

# Get top k documents with highest similarity scores and check k is not greater than total 
#documents
k = 5
k = min(k, len(documents))

top_k_indices = np.argpartition(cosine_similarities[0], -k)[-k:]
top_k_sorted_indices = top_k_indices[np.argsort(cosine_similarities[0][top_k_indices])[::-1]]

for idx in top_k_sorted_indices:
    print(f"Score: {cosine_similarities[0][idx]:.4f} - Document: {documents[idx]}")
